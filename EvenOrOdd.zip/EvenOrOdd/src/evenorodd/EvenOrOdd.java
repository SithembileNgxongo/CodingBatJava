/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package evenorodd;

/**
 *
 * @author 10015547
 */
public class EvenOrOdd {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int [] numbers = {2,5,6,8,7};
      
      String ans = oddOrEven(numbers);
      
      System.out.println(ans);
    }
    public static String oddOrEven (int[] array) {
   String ans = "";
   int total = 0;
   if(array.length<=0) {
     ans = "The array is empty";
   }
   else{
     for(int i = 0; i < array.length; i++){
        total = total+ array[i];
     }
     //making sure that he total is not zero
     if(total>0){
     //checking odd or even numbers
       if(total%2==0){
       ans = "even";
       }
       else{
       ans = "odd";
       }
     }
     else{
         ans = "the total is zero";
     }
    }
   return ans;
   }
  
}
