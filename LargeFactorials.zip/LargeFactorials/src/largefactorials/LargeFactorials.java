package largefactorials;

import java.math.*;
public class LargeFactorials {
    public static void main(String[] args) {
        System.out.println(f(10));
    }
   public static String f(int n){BigDecimal a=BigDecimal.ONE;for(int i=1;i<=n;i++)a=a.multiply(BigDecimal.valueOf(i));return""+a;}
}
