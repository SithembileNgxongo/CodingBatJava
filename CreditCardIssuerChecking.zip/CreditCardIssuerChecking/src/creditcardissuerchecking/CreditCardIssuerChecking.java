/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creditcardissuerchecking;

/**
 *
 * @author 10015547
 */
public class CreditCardIssuerChecking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String is = getIssuer("8011111111111117");
        
        System.out.println(is);
    }
    public static String getIssuer(String cardNumber){
        String amexMastercard = cardNumber.substring(0,2);
        String discover =cardNumber.substring(0,4);
        String visa = cardNumber.substring(0,1);
        String ans ="";
        int number = cardNumber.length();
        
        switch(number){
            case 15:
                //amex
                if(amexMastercard.equals("34") || amexMastercard.equals("37")){
                     ans = "AMEX";
                }
                else{
                    ans = "Unknown";
                }
               break;
            case 16:
                if(amexMastercard.equals("51") || amexMastercard.equals("52") || amexMastercard.equals("53")||amexMastercard.equals("54")|| amexMastercard.equals("55")){
                     ans = "Mastercard";
                }
                else if(discover.equals("6011")){
                     ans = "Discover";
                }
                else if(visa.equals("4")){
                     ans = "VISA";
                }
                else{
                    ans = "Unknown";
                }
                break;
            case 13:
                if(visa.equals("4")){
                     ans = "VISA";
                    }
                else{
                    ans = "Unknown";
                }
               break;
            default:
              ans = "Unknown";
                break;
                
        }
        
        return ans;
        
      
    }
}
