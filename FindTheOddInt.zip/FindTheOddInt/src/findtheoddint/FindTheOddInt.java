/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package findtheoddint;

/**
 *
 * @author 10015547
 */
import java.util.HashMap;
public class FindTheOddInt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int [] test = {1, 2, 3, 2, 3, 1, 3};
    System.out.println(findTheOddInt(test));
    }
    public static int findTheOddInt(int[]a){
  int n = a.length;
 HashMap<Integer,Integer> hmap = new HashMap<>(); 
          
        // Putting all elements into the HashMap 
        for(int i = 0; i < n; i++) 
        { 
            if(hmap.containsKey(a[i])) 
            { 
                int val = hmap.get(a[i]); 
                          
                hmap.put(a[i], val + 1);  
            } 
            else
                hmap.put(a[i], 1);  
        } 
  
        for(Integer va :hmap.keySet()) 
        { 
            if(hmap.get(va) % 2 != 0) 
                return va; 
        } 
        return -1; 
    }
}
