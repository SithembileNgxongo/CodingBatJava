/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package getthemiddlecharacter;

/**
 *
 * @author 10015547
 */
public class GetTheMiddleCharacter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String ans = getMiddle("aca");
       System.out.println(ans);
    }
    public static String getMiddle(String word){
        String ans ;
        int len = word.length();
        char[] newWord = word.toCharArray();
        int middle = len/2;
        if(len <=2){
            ans = word;
        }
        else{
            if(len%2==0){
              
              ans = ""+newWord[middle-1] + newWord[middle]; 
            }
            else {
             
              ans = ""+newWord[middle];
            }
        }
        return ans;
    }
    
}
