/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package needleinthehaystack;

/**
 *
 * @author 10015547
 */
public class NeedleInTheHaystack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Object [] hay =  {"3", "123124234", null, "needle", "world", "hay", 2, "3", true, false};
    String ans = findNeedle(hay);
    System.out.println(ans);
    }
    public static String findNeedle(Object [] haystack){
        String a = "i";
        for(int i = 0; i < haystack.length; i ++){
            if(haystack[i]!=null&& haystack[i].equals("needle") ){
                a = "found the needle at position " + i;
            }
   
        }
        return a ;
    }
}
