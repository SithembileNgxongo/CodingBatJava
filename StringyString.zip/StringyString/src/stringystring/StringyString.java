/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringystring;

/**
 *
 * @author 10015547
 */
public class StringyString {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String a =  stringy(0);
        System.out.println(a);
    }
      public static String stringy(int size) {
   String ans = "1";
   if(size > 0){
          for(int i = 0 ;  i  < size -1 ; i++){
       if(ans.substring(i).equals("1")){
           ans = ans + "0";
       }else{
           ans =  ans + "1";
       }
   }
   }else{
       ans = "0";
   }
   return ans;
  }
}
