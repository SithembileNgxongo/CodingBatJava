/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vowelcount;

/**
 *
 * @author 10015547
 */
public class VowelCount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String str = "Aithe";
        int a = vowelCount(str);
        System.out.println(a);
    }
    public  static int vowelCount(String str){
        int count = 0 ;
        char[] vowels = {'a','e','i','o','u'};
        char[] charStr = str.toLowerCase().toCharArray();
        
        for(int i = 0 ; i < charStr.length; i++){
            for(int a = 0 ; a < vowels.length; a++){
                if(charStr[i]==vowels[a]){
                    count = count + 1 ;
                }
            }
        }
        
        return count;
    }
    
}
