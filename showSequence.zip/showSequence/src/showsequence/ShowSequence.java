/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package showsequence;

/**
 *
 * @author 10015547
 */
public class ShowSequence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            String a = showSequence(6);
       System.out.println(a);
    }
        public static String showSequence(int value){
        String ans = "0";
        int total = 0 ;
        String str = "";
        if(value == 0 ){
            str = "0=" + total;
        }else if (value < 0){
            str  = value + " < " + total;
            
        }
        else{
        for(int i  = 1 ; i <=  value; i++){
            ans = ans + "+" + i ;
            total = total  + i ;
        }
        
        str= ans + " = " +  total;
        }
        
        return str;
  }
}
