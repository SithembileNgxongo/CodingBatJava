/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aretheythesame;

/**
 *
 * @author 10015547
 */
public class AreTheyTheSame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] a= {1211,9};
        int [] b = {5,11,3};
        boolean check = comp(a, b);
        System.out.println(check);
    }
  public static boolean comp(int[] a, int[] b) {
      int aTotal = 0, bTotal= 0;
      boolean ans = false;
      int newTotal = 0 ;

      for(int i = 0 ; i < a.length; i ++){
          aTotal = aTotal + a[i];
      }
      
      for(int i = 0 ;  i < b.length; i ++){
          bTotal =  bTotal + b [i];
      }
      
      if(aTotal < bTotal){
                int [] newA = new int[a.length];
                for(int i = 0 ;  i < a.length; i ++){
                    newA[i] = a[i]* a [i];
               }
                for(int i = 0 ; i < newA.length; i ++){
                        newTotal  = newTotal + newA[i];
                }
                if(newTotal==bTotal){
                    ans = true;
                }
        }else{
               int [] newB = new int[b.length];
                for(int i = 0 ;  i < b.length; i ++){
                    newB[i] = b[i]* b [i];
               }
                for(int i = 0 ; i < newB.length; i ++){
                        newTotal  = newTotal + newB[i];
                }
                if(newTotal==aTotal){
                    ans = true;
                }
      }

    return ans;
  }
    
}
