/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bumpsontheroad;

/**
 *
 * @author 10015547
 */
public class BumpsOnTheRoad {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String ans = bumps("______n___n_");
        System.out.println(ans);
    }
   public static String bumps(final String road) {
       char[] a =  road.toCharArray();
      
       int bump = 0 ;
       String ans = "";
       for(int i = 0 ; i < a.length; i ++){
           if(a[i]=='n'){
               bump = bump+ 1 ;
           }
       }
       if(bump < 15 || bump==15){
           ans = "Woohoo";
       }else{
           ans = "Car Dead";
       }
       
    return ans;
  }
    
}
