/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package predictyourage;

/**
 *
 * @author 10015547
 */
public class PredictYourAge {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       int a = predictAge(32,54,76,65,34,63,64,45);
        System.out.println(a);
    }
     public static int predictAge(int age1, int age2, int age3, int age4, int age5, int age6, int age7, int age8) {
         int newAge1 , newAge2 , newAge3, newAge4, newAge5, newAge6, newAge7, newAge8 ;
        newAge1 = age1* age1;
        newAge2 = age2* age2;
        newAge3 = age3* age3;
        newAge4 = age4* age4;
        newAge5 = age5* age5;
        newAge6 = age6* age6;
        newAge7 = age7* age7; 
        newAge8 = age8* age8;        
             
           
         int add = newAge1  +newAge3 +newAge4 +newAge5 +newAge6 +newAge7 +newAge8 +newAge2 ;
         double addAnswer = Math.sqrt(add);
         double answer = addAnswer/2.0;
     
       return (int)answer;
    }
}
