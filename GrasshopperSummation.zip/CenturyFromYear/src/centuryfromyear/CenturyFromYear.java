/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centuryfromyear;

/**
 *
 * @author 10015547
 */
public class CenturyFromYear {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = century(1601);
        System.out.println(a);
    }
      public static int century(int number) {
      double ans = number/100.0;
          
      return (int) Math.ceil(ans);
  }
}
