/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abbreviatetwowordname;

/**
 *
 * @author 10015547
 */
public class AbbreviateTwoWordName {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println(abbrevName("Sithe Ngxongo"));
    }
        public static String abbrevName(String name) {
    String [] str =  name.toUpperCase().split(" ");
    String ans = "";
    
    for(int i = 0 ; i < str.length; i ++){
        ans = ans+ str[i].substring(0,1)+".";
    }
    String b = "";
    String a = ans.substring(ans.length()-1);
    if(a.equals(".")){
        b = ans.substring(0,ans.length()-1);
    }
    else{
        b= a;
    }
    return b;
  }
}
