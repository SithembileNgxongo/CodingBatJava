package countvowel;

import java.util.Scanner;

public class CountVowel {


    public static void main(String[] args) {
        Scanner scanner  = new Scanner(System.in);
        String count  = "";
        boolean repeat  =  true;
        
        while(repeat){
        System.out.println("Do you want to count\n 1. Count All the Vowels\n 2.Count Individual Vowels ");
        String menu = scanner.nextLine();
        if(menu.equals("1")|| menu.equals("2")){
        System.out.println("Please enter a word or phrase that you want to count the vowels for");
        String word =  scanner.nextLine();
    
        
        switch(menu){
            case "1":
                count  = countAllTheVowel(word);
                break;
            case "2":
                  count =  countVowel(word); 
                break;
          }
        
       System.out.println(count);
       repeat  = false;
       
        }else{
            System.out.println();
            System.out.println("The number is not included in the Menu above ...");
            System.out.println();
            repeat  =  true;
        }
        }
    }
    public static String countVowel(String word){
        int countA  = 0;  
        int countE  = 0;
        int countI  = 0;
        int countO  = 0;
        int countU  = 0;
        
        char [] wordArray  =  word.toLowerCase().toCharArray();
        
        for(int i =   0 ;  i  < wordArray.length ;   i ++ ){
            
            switch (Character.toString(wordArray[i])) {
                case "a":
                    countA = countA + 1;
                    break;
                case "e":
                    countE  =  countE + 1;
                    break;
                case "i":
                    countI  = countI  + 1;
                    break;
                case "o":
                    countO  =  countO + 1;
                    break;
                case "u":
                    countU = countU  + 1;
                    break;
                default:
                    break;
            }
        }
        if((countA  == 0 )&(countE == 0)&(countI == 0)&(countO == 0)&(countU == 0)){
            return word.toUpperCase() + " does not have any vowels.";
        }else{
          return word + " has the following vowels : \n"+ "A = " + countA + "\n" +"E = " + countE + "\n" +"I = " + countI + "\n" + "O = " + countO +  "\n" + "U = " + countU;
        }
    }
    
    public static String countAllTheVowel(String word){
        int count  = 0 ;
        
        char [] wordArray  = word.toLowerCase().toCharArray();
        
        for(int i = 0 ;  i < wordArray.length ; i ++){
            if(Character.toString(wordArray[i]).equals("a")
              || Character.toString(wordArray[i]).equals("e")
              || Character.toString(wordArray[i]).equals("i")
              || Character.toString(wordArray[i]).equals("o")
              || Character.toString(wordArray[i]).equals("u")){
                count =  count + 1;
            }
        }
        
        if(count  == 0 ){
            return word.toUpperCase() +" does not have any vowels";
        }else{
            return word.toUpperCase() + " has " + count +" vowels";
        }
    }
}
