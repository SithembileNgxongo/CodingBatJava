/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maxmultiple;

/**
 *
 * @author 10015547
 */
public class MaxMultiple {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int ans = maxMultiple(37, 200);
     
     System.out.println(ans);
    }
    public static int maxMultiple(int divisor, int bound){
        int ans = 0;
       
        //takes the bound value and goes through it 
        for(int i = 1; i <= bound; i ++){
            //checks if the values that is from 1 and bound is divided by the devisor 
            if(i%divisor==0){
                ans = i;
            }
        }
        return ans;
    }
}
