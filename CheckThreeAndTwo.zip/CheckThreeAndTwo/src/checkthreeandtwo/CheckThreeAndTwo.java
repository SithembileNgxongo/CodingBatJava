/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package checkthreeandtwo;

/**
 *
 * @author 10015547
 */
public class CheckThreeAndTwo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    char [] chars  = {'c','c','c','b','b'};
    
    boolean ans = checkCharacters(chars);
    
    System.out.println(ans);
    }
    public static boolean checkCharacters(char [] chars){
        int a = 0, b = 0,c = 0;
        
        for(int i = 0; i < chars.length; i++){
            switch(chars[i]){
                case 'a':
                     a = a +1;
                    break;
                case 'b':
                       b = b +1;
                    break;
                case  'c':
                     c = c +1;
                    break;
            }
        }

         if((a == 3) && (c==2)){  return true;}
            else if((a == 3) && (b==2)){ return true; }
              else if ((b == 3) && (c==2)){ return true; }
                else if ((c == 3) && (b==2)){ return true;}
                   else if((a == 2) && (c==3)){ return true; }
                         else if ((b == 3) && (a==2)){ return true; }
         else{
                return false;  
         }
  
    }
    
}
