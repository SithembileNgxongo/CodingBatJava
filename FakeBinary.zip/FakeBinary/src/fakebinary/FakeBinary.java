/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fakebinary;

/**
 *
 * @author 10015547
 */
public class FakeBinary {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String a = fakeBin("5656554");
       System.out.println(a);
    }
        public static String fakeBin(String numberString) {
            String one = numberString.replace("1","0");
            String two = one.replace("2", "0");
            String three = two.replace("3", "0");
            String four = three.replace("4", "0");
            String five = four.replace("5", "0");
            String six = five.replace("6", "1");
            String seven = six.replace("7", "1");
            String eight = seven.replace("8", "1");
            String nine = eight.replace("9", "1");
        return nine;
    }
}
