/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package allstarcodechallange18;

/**
 *
 * @author 10015547
 */
public class AllStarCodeChallange18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a  =  strCount("Hello", 'l');
        System.out.println(a);
    }
      public static int strCount(String str, char letter) {
    String check =  str.toLowerCase();
    char[] word =  check.toCharArray();
    int total = 0;
    
    for(int i  = 0 ; i < word.length; i ++ ) { 
    if(word[i] == letter) {
      total =  total + 1;
    }
    }
    return total;
  }
}
